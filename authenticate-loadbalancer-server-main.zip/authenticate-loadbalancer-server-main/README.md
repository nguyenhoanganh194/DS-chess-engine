# DS-project
 The DS project oulu course
## Project Instructions:

Install docker and open the terminal
 ```docker
docker build -t auth_server .
docker run -it -p {portHTTP}:{8001} auth_server
```
